
// JavaScript logic for the project
const form = document.getElementById('registroForm');
const registrosTable = document.getElementById('registrosTable').querySelector('tbody');
const totalesDiv = document.getElementById('totales');
const granTotalDiv = document.getElementById('granTotal');
const imprimirBtn = document.getElementById('imprimir');

let registros = JSON.parse(localStorage.getItem('registros')) || [];

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const fecha = document.getElementById('fecha').value;
    const dia = document.getElementById('dia').value;
    const horasTrabajadas = parseFloat(document.getElementById('horasTrabajadas').value);
    const precioPorHora = parseFloat(document.getElementById('precioPorHora').value);
    const pasajes = parseFloat(document.getElementById('pasajes').value);
    const total = Number((horasTrabajadas * precioPorHora).toFixed(2)); // Ensure correct precision

    registros.push({ fecha, dia, horasTrabajadas, precioPorHora, total, pasajes });
    localStorage.setItem('registros', JSON.stringify(registros));
    renderRegistros();
    form.reset();
});

function renderRegistros() {
    registrosTable.innerHTML = registros.map((registro, index) => `
        <tr>
            <td>${registro.fecha}</td>
            <td>${registro.dia}</td>
            <td>${registro.horasTrabajadas}</td>
            <td>${registro.precioPorHora.toFixed(2)}</td>
            <td>${registro.total.toFixed(2)}</td>
            <td>${registro.pasajes.toFixed(2)}</td>
            <td class="acciones">
                <button class="btn btn-danger btn-sm" onclick="eliminarRegistro(${index})">Eliminar</button>
            </td>
        </tr>
    `).join('');
    calcularTotales();
}

function eliminarRegistro(index) {
    registros.splice(index, 1);
    localStorage.setItem('registros', JSON.stringify(registros));
    renderRegistros();
}

function calcularTotales() {
    const totalHoras = registros.reduce((sum, reg) => sum + reg.horasTrabajadas, 0);
    const totalSueldo = registros.reduce((sum, reg) => sum + reg.total, 0);
    const totalPasajes = registros.reduce((sum, reg) => sum + reg.pasajes, 0);
    const granTotal = Number((totalSueldo + totalPasajes).toFixed(2)); // Ensure correct precision

    totalesDiv.innerHTML = `
        Total de Horas: ${totalHoras.toFixed(1)} horas<br>
        Total por Horas: ${totalSueldo.toFixed(2)}$<br>
        Total Pasajes: ${totalPasajes.toFixed(2)}$
    `;

    granTotalDiv.innerHTML = `Total: ${granTotal.toFixed(2)}$`;
}

imprimirBtn.addEventListener('click', () => {
    window.print();
});

renderRegistros();
